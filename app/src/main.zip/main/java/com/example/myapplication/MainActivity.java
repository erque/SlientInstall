package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.pm.IPackageDeleteObserver;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class MainActivity extends AppCompatActivity {

    private Button mBtInstall;
    private Button mBtUninstall;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;

    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        verifyStoragePermissions();
        mBtInstall = findViewById(R.id.bt_install);
        mBtUninstall = findViewById(R.id.bt_uninstall);
        mBtInstall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Give an example
                silentInstall("/mnt/sdcard/123.apk");

            }
        });
        mBtUninstall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Give an example
                silentUnInstall("com.example.testbroadcast");
            }
        });
    }

    /**
     * Request file read and write permissions
     */
    public void verifyStoragePermissions() {
        try {
            int permission = ActivityCompat.checkSelfPermission(this,
                    "android.permission.WRITE_EXTERNAL_STORAGE");

            if (permission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Install APK silently
     *
     * @param apkPath .apk file path
     * @return
     */
    public boolean silentInstall(String apkPath) {
        PackageManager packageManager = getApplicationContext().getPackageManager();
        Class<?> pmClz = packageManager.getClass();
        try {
            Class<?> aClass = Class.forName("android.app.PackageInstallObserver");
            Constructor<?> constructor = aClass.getDeclaredConstructor();
            constructor.setAccessible(true);
            Object installObserver = constructor.newInstance();
            Method method = pmClz.getDeclaredMethod("installPackage", Uri.class, aClass, int.class, String.class);
            method.setAccessible(true);
            method.invoke(packageManager, Uri.fromFile(new File(apkPath)), installObserver, 2, null);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * UnInstall APK silently
     *
     * @param packageName
     * @return
     */
    public boolean silentUnInstall(String packageName) {
        PackageManager packageManager = getApplicationContext().getPackageManager();
        Class<?> pmClz = packageManager.getClass();
        try {
            Method method = pmClz.getDeclaredMethod("deletePackage", String.class, IPackageDeleteObserver.class, int.class);
            method.setAccessible(true);
            method.invoke(packageManager, packageName, null, 2);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}